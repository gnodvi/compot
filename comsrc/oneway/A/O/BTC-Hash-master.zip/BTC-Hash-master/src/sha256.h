#include <stdint.h>

void sha256_hash(const uint8_t input[], const uint64_t msgBytes, uint32_t hash[8]);

