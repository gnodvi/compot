# Bitcoin.jl

[![pipeline status](https://gitlab.com/braneproject/Bitcoin.jl/badges/master/pipeline.svg)](https://gitlab.com/braneproject/Bitcoin.jl/commits/master)    [![coverage report](https://gitlab.com/braneproject/Bitcoin.jl/badges/master/coverage.svg)](https://gitlab.com/braneproject/Bitcoin.jl/commits/master)

A Julia Bitcoin library inspired by Jimmy Song's Programming Blockchain seminar
and learning materials.

## Documentation

https://braneproject.gitlab.io/Bitcoin.jl/

## Buy me a cup of coffee

[Donate Bitcoin](bitcoin:34nvxratCQcQgtbwxMJfkmmxwrxtShTn67)
