using Documenter, Bitcoin

makedocs(sitename="Bitcoin",
         doctest=true)
