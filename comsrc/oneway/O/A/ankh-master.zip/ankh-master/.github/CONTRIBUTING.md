
Hello and welcome to __ANKH__, Andreas Kupries' Hashes.

__Attention please__

You are reading this on github __mirror__ of the ANKH sources.

:warning: This is __not__ the location where ANKH development takes place.

:warning: We are __not tracking issues entered here__. At best we will
simply close the issue with a reference to the official locations of
source and ticket tracker.

Please go to the
[official location of the sources](https://core.tcl-lang.org/akupries/ankh)
and enter your ticket into the
[official ticket tracker](https://core.tcl-lang.org/akupries/ankh/reportlist)
instead.

Thank you for your consideration.
