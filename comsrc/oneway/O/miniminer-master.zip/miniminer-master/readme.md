# miniminer


![Alt text](thumb.jpg "Project screenshot")

A minimalistic full working bitcoin miner implemented in python.

The objetive of this projects is to write the simplest miner ever to be embeded in different art projects. 
If you plan to use it in your project **please give credit!**

2017 used in the ([Bittercoin](http://martinnadal.eu/artworks/bittercoin/)) project 

contact: martin(at)muimota.net
