websocketd --port=8082 --devconsole ./client.rb
