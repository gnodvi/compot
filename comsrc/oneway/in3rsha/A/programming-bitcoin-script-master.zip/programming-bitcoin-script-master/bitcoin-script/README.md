
# Bitcoin Script Test Simulator / Stack Machine - Code 'n' Run Your Own Bitcoin (Crypto) Contract Transaction Scripts

bitcoin-script gem / library - bitcoin script test simulator / stack machine - code 'n' run your own bitcoin (crypto) contract transaction scripts

* home  :: [github.com/openblockchains/programming-bitcoin-script](https://github.com/openblockchains/programming-bitcoin-script)
* bugs  :: [github.com/openblockchains/programming-bitcoin-script/issues](https://github.com/openblockchains/programming-bitcoin-script/issues)
* gem   :: [rubygems.org/gems/bitcoin-script](https://rubygems.org/gems/bitcoin-script)
* rdoc  :: [rubydoc.info/gems/bitcoin-script](http://rubydoc.info/gems/bitcoin-script)


## Usage

To be done



## License

![](https://publicdomainworks.github.io/buttons/zero88x31.png)

The `bitcoin-script` scripts are dedicated to the public domain.
Use it as you please with no restrictions whatsoever.


## Questions? Comments?

Send them along to the [wwwmake forum](http://groups.google.com/group/wwwmake).
Thanks!
