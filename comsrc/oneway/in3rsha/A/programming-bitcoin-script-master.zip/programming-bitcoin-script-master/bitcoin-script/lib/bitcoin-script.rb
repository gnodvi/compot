# encoding: utf-8

require 'pp'

## our own code
require 'bitcoin-script/version'    # note: let version always go first



puts BitcoinScript.banner    ## say hello
