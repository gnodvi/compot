## minitest setup

require 'minitest/autorun'


## our own code

require 'bitcoin-script'
