# encoding: utf-8

###
#  to run use
#     ruby -I ./lib -I ./test test/test_ops.rb


require 'helper'


class TestOps < MiniTest::Test

end  # class TestOps
