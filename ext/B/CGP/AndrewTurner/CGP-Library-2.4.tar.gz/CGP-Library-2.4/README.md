CGP Library
======

A cross platform Cartesian Genetic Programming Library written in C.

Author: Andrew James Turner    
Webpage: http://www.cgplibrary.co.uk/     
Email: andrew.turner@york.ac.uk    
License: Lesser General Public License (LGPL)    

