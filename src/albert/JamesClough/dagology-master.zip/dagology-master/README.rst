Dagology
========

Dagology is a Python package for the study of the structure of
directed acyclic graphs (DAGs).

Download
--------

To get the git version do

::

    $ git clone  git://github.com/JamesClough/dagology.git

NetworkX, numpy, scipy and matplotlib are required for dagology


Bugs
----

Please report any bugs that you find to me at
james.clough91@gmail.com
Or even better, fork and make a pull request.

License
-------

See LICENSE.txt::

   Copyright (C) 2017
   James Clough <james.clough91@gmail.com>
