#!/bin/bash

cd ..
zip  studgeod.zip  \
StudGeod/*.ini \
StudGeod/*.cfg \
StudGeod/*.obj \
StudGeod/*.png \
cd StudGeod
