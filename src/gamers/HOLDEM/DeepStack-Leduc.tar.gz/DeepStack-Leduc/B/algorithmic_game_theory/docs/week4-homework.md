# 1) Computing Nash Equilibrium using LP
 - Find Nash Equilibrium in zero-sum game using LP formulation

# 1) Computing Correlated Equilibrium using LP
- Find Correlated Equilibrium in zero-sum game using LP formulation
- Find Correlated Equilibrium in non-zero-sum game using LP formulation
