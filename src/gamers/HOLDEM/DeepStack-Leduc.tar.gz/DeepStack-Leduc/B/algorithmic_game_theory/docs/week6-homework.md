# 1) Best Response Calculation
 - Implement a function that computes best response in an extensive form game

# 2) Fictitious Self-Play in Extensive Form Games
- Implement a function that computes fictitious self-play in an extensive form game
- Remember to correctly average the behavioral strategies
- Plot the exploitability of the averaged strategy in Kuhn poker
