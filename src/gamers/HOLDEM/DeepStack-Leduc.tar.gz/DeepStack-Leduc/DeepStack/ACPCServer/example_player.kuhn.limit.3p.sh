#!/bin/bash
./example_player kuhn.limit.3p.game $1 $2
