#include "THLapack.h"

#include "generic/THLapack.c"
#include "THGenerateFloatTypes.h"
