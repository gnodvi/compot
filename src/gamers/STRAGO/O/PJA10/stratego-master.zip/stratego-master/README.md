# stratego

The classic stratego game for two playes. Based on pygame and sockets.
