# Minesweeper

## How To play with AI
* Press <kbd>Space</kbd> to AI move.
* Press <kbd>Backspace</kbd> to go back up to 50 moves.
