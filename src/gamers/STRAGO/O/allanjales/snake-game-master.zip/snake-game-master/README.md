# Snake Game
> Classic Snake Game with I.A. option

## How can I run it?
Made in Javascript you just need to download and open in your browser.

## How do I play?
You play using your <kbd>arrow</kbd> keys from keyboard

## What does the buttons?
* The big red button makes I.A. plays
* The little light shows debug if you click.
