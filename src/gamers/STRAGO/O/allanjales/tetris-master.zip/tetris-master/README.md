# tetris
Recreation of classic game tetris

[Play](https://allanjales.github.io/tetris/Tetris.html)
