# Plain move
MOVE = 0

ATTACK_DRAW = 1

# Plain attack won
ATTACK_WON = 2

# Plain attack lost :(
ATTACK_LOST = 3

# Flag capture
CAPTURE = 4
