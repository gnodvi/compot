package nl.hva.ewa.stratego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrategoApplication {

    public static void main(String[] args) {
        SpringApplication.run(StrategoApplication.class, args);
    }

}
