import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-continue-game',
  templateUrl: './continue-game.component.html',
  styleUrls: ['./continue-game.component.css']
})
export class ContinueGameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
