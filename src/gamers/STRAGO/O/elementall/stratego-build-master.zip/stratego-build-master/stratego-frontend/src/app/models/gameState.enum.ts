export enum GameState {
  await = 'waiting for invite',
  setup = 'setup',
  atplay = 'atplay',
  finished = 'finished',
}
