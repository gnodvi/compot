
export enum PieceName {
  Bomb = 'Bomb',
  Marshal = 'Marshal',
  General = 'General',
  Colonel = 'Colonel',
  Major = 'Major',
  Captain = 'Captain',
  Lieutenant = 'Lieutenant',
  Sergeant = 'Sergeant',
  Miner = 'Miner',
  Scout = 'Scout',
  Spy = 'Spy',
  Flag = 'Flag',
  Empty = 'empty'
}
