export enum PieceStatus {
  Dood,
  Levend,
  empty
}
