
export enum PlayerStatus {
  Online = 'online',
  Offline = 'offline'
}
