# Stratego
Stratego Game using AI
you can add and remove some lines to enhance the code . 
I appreciate you.
