
# don't pass arg --use-strict to node
# https://stackoverflow.com/a/51970329/6157047

node dist/server.js
