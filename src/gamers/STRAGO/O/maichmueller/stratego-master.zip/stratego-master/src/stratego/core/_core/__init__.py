from ._cpp_lib import Logic

all = ("Logic", )