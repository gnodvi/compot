
#include "stratego/logic.h"
