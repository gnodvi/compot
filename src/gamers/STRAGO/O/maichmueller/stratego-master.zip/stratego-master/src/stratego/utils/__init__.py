from .utils import Singleton, slice_kwargs, RollingMeter, rng_from_seed
