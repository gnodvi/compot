### Stratepig Launcher
Windows exclusive (for now) launcher for [Stratepig](https://stratepig.com).<br/>
Integrates with the Elixir [update server](https://github.com/miapolis/stratepig-server/tree/main/stratepig_updater).

<img src="/docs/ss1.png" width="750px">
