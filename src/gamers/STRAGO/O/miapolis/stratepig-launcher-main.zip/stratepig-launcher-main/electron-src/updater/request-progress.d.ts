declare module "request-progress" {
  export default function (
    request: any
  ): any
}
