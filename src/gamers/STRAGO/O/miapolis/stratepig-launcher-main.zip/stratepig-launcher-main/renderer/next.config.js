module.exports = {
  reactStrictMode: true,
  target: "serverless",
};
