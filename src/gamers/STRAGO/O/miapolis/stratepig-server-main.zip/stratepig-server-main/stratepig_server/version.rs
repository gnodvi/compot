pub const VERSION: &'static str = env!("CARGO_PKG_VERSION");
