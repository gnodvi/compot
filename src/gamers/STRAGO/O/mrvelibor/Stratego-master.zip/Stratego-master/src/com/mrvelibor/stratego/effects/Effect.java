package com.mrvelibor.stratego.effects;

import com.mrvelibor.stratego.graphics.Drawable;

public abstract class Effect implements Drawable {
	
	public abstract boolean effect(int x, int y);
	
}
