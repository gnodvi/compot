package com.mrvelibor.stratego.exceptions;

public class FieldNotPassableExteption extends StrategoException {
	
	private static final long serialVersionUID = 1L;
	
}
