package com.mrvelibor.stratego.exceptions;

public abstract class StrategoException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
}
