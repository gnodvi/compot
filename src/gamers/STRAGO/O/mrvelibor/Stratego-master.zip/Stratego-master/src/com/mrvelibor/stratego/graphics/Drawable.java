package com.mrvelibor.stratego.graphics;

import java.awt.Graphics2D;

public interface Drawable {
	
	public void draw(Graphics2D g);
	
}
