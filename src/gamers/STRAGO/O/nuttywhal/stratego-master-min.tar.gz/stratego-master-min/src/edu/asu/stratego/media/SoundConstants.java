package edu.asu.stratego.media;

import javafx.scene.media.AudioClip;

public class SoundConstants {
	// TODO Sound constant disabled
    //public final static AudioClip CORNFIELD = new AudioClip(SoundConstants.class.getResource("sound/cornfield.mp3").toString());
}