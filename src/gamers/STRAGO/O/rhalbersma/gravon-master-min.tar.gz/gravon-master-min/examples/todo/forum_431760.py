#          Copyright Rein Halbersma 2018-2021.
# Distributed under the Boost Software License, Version 1.0.
#    (See accompanying file LICENSE_1_0.txt or copy at
#          http://www.boost.org/LICENSE_1_0.txt)

# http://forum.stratego.com/topic/357378-strategy-question-findingavoiding-bombs-at-the-end-of-games/?p=431760
print('TODO: implement first move statistics')
