# Stratego

Please refer to README.pdf for project description
