import { Piece } from './piece';

describe('Piece', () => {
  it('should create an instance', () => {
    expect(new Piece()).toBeTruthy();
  });
});
