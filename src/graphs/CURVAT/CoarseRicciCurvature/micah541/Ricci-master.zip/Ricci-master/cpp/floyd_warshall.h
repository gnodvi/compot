#ifndef floyd_warshall_h__
#define floyd_warshall_h__

#ifdef __cplusplus
extern "C" {
#endif

extern void fw(double* C, int n);

#ifdef __cplusplus
}
#endif

#endif
