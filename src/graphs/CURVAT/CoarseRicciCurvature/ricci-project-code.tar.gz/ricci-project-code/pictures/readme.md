3d2 is a picture with 400 pts created from normal distributions centered at simplex with vertices space 7 units from origin.   

NoisyMoonsMarch25 shows some noisy moons

NoisyCirclesMarch29 shows some noisy circles (400 pts, factor = .5 noise = .05) 




I'm leaving some pictures in here just for historical nostalgia.

I recently added some fixed data sets on which the clustering works.


----------------------------------
perm_circles_200_1 data : 
eta = 0.0075 
threshold = 0.05  
upperthreshold = 0.3 
rescale = 'L1'
t,T = 0.2 
