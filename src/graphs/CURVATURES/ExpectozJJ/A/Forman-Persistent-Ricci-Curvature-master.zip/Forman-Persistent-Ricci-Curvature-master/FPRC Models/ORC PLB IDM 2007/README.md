
* (1）you can download the PDBbind data from this website   www.pdbbind.org.cn

* (2）in order to use our code, you need to build the same folder structures like here 
     
* (3) there is a folder for each of intermediate data, please test with our code to see how the code runs.
