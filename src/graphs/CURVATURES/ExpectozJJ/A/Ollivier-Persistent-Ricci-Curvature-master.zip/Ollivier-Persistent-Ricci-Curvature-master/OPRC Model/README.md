The list of python files consists of all the subfunctions used in dataset preparation of PDBbind v2007, v2013 and v2016. 

Original Datasets can be downloaded from www.pdbbind.org.cn.
