.. role:: hidden
    :class: hidden-section
.. currentmodule:: {{ module }}

{{ name | underline}}

.. autoclass:: {{ name }}
    :show-inheritance:
    :members: forward, loss_func, process_graph
