A Blitz Introduction
====================
