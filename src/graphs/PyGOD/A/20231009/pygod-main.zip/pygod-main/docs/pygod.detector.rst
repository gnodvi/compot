pygod.detector
==============

.. autosummary::
    :nosignatures:
    :toctree: ./generated/
    :template: detector.rst

    ~pygod.detector.AdONE
    ~pygod.detector.ANOMALOUS
    ~pygod.detector.AnomalyDAE
    ~pygod.detector.CoLA
    ~pygod.detector.CONAD
    ~pygod.detector.DOMINANT
    ~pygod.detector.DONE
    ~pygod.detector.GAAN
    ~pygod.detector.GAE
    ~pygod.detector.GUIDE
    ~pygod.detector.OCGNN
    ~pygod.detector.ONE
    ~pygod.detector.Radar
    ~pygod.detector.SCAN
