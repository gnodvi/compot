pygod.generator
===============

.. automodule:: pygod.generator
    :members: gen_contextual_outlier, gen_structural_outlier
    :undoc-members:
