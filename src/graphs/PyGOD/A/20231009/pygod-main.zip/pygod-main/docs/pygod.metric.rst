pygod.metric
============

.. automodule:: pygod.metric
    :members: eval_average_precision, eval_f1, eval_precision_at_k, eval_recall_at_k, eval_roc_auc
    :undoc-members:
