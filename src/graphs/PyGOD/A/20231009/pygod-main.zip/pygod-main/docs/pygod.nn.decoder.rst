pygod.nn.decoder
================

.. autoclass:: pygod.nn.decoder.DotProductDecoder
    :members:
    :undoc-members:
    :exclude-members: training
