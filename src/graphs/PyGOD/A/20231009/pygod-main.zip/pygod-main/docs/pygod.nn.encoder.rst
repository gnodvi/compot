pygod.nn.encoder
================

.. automodule:: pygod.nn.encoder
   :members:
   :undoc-members:
   :exclude-members: training
