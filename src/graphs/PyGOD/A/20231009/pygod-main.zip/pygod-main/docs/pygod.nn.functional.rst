pygod.nn.functional
===================

.. automodule:: pygod.nn.functional
    :members:
    :exclude-members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:
