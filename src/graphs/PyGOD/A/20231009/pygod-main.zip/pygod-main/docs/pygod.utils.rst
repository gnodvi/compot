pygod.utils
===========

Data Loading
------------

.. autoclass:: pygod.utils.load_data
    :members:
    :undoc-members:

Score Conversion
----------------

.. autofunction:: pygod.utils.to_edge_score

.. autofunction:: pygod.utils.to_graph_score

