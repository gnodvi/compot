Core Team
=========

PyGOD is a great team effort by researchers from UIC, IIT, BUAA, ASU, and CMU. Our core team members include:

`Kay Liu (UIC) <https://kayzliu.com/>`_

`Yingtong Dou (UIC) <http://ytongdou.com/>`_

`Yue Zhao (CMU) <https://www.andrew.cmu.edu/user/yuezhao2/>`_

`Xueying Ding (CMU) <https://scholar.google.com/citations?user=U9CMsh0AAAAJ&hl=en>`_

`Xiyang Hu (CMU) <https://www.andrew.cmu.edu/user/xiyanghu/>`_

`Ruitong Zhang (BUAA) <https://github.com/pygod-team/pygod>`_

`Kaize Ding (ASU) <https://www.public.asu.edu/~kding9/>`_

`Canyu Chen (IIT) <https://github.com/pygod-team/pygod>`_