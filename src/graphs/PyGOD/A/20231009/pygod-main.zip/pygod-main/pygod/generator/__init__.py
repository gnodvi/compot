from .outlier_generator import gen_contextual_outlier
from .outlier_generator import gen_structural_outlier

__all__ = ['gen_contextual_outlier', 'gen_structural_outlier']
