# CellularAutomata
Micro-structure Grain Growth Simulation 
# Main file rn: cellularAutomata.py
