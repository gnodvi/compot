# Order  (epsilon)

ord_status = False

ord_var = ''

ord_n = 0