def covariant_derividive():
    return True

def tensor_constraction():
    return True

    """
    Cotton tensor functions
    =======================
    """

    def get_cotton_coefficient(self):
        return True

    def set_cotton_coefficient(self):
        return True

    def set_all_cotton_coefficients(self):
        return True

    def compute_cotton_coefficient(self):
        if(self.suppress_printing == False):
            print("")
            print("")
            print("Cotton Coefficients")
            print("===================")
        for lam in self.dimensions:
            print("")
            acc = 0

    def print_separation_geodesic(self, lam):
        return True

    def print_all_separation_geodesics(self):
        return True