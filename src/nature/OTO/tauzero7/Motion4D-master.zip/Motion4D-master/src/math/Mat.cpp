/**
 * @file    Mat.cpp
 * @author  Thomas Mueller
 *
 * This file is part of the m4d-library.
 */
#include "Mat.h"
