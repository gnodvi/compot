# xzoom with follow mouse and show cursor

Full description at https://seguridad-agile.blogspot.com/2020/05/xzoom-mejorado.html

Motivation at https://seguridad-agile.blogspot.com/2020/05/xzoom-mejora-zoom.html

## Done
* xzoom taken from debian repo
* modifications to follow mouse taken from https://github.com/mbarakatt/xzoom-follow-mouse
* added command line and runtime options to change that
* added cursor in magnifier

## TODO

* show new options in title
* support rotations
