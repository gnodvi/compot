# General-Relativity-calculator
Python code to generate the symbols of Christofell, the Riemann tensor, Ricci and the scalar curvature for any metric.

## Metric

- You can change the metric, using the variables above.

## Metric variable

- These are the variables with which we will derive the metric.
   You can also change them.
   
## To LaTeX


- To be able to generate the file in LaTeX, you have to change the path,

             Path ="		/Users/thomasstinglhamber/Desktop/RG_ALL/LaTeX_RG_4x4.txt		"

by setting your path and setting the variable "ToLaTeX" = True (False to not generate the file).

After running the code, a txt file. will appear following the path
Just copy paste it into Overleaf to see more easily
the results only in the terminal.


#### There is nothing more to modify

Have fun.
