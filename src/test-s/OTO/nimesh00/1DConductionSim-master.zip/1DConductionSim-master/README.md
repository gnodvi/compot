# 1DConductionSim
Simulation of (Non-)Linear 1D heat conduction equation solution.
