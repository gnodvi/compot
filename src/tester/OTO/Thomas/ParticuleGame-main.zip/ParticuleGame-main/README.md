# ParticuleGame

## Create all Baryons and Mesons based on elementary quarks!
### How to play ?
First of all, you have to go to the “combination” game mode. Once in this mode, you click on the quarks in the column on the right, they will appear in the central zone of combination. From there, you have to click and drag the quarks on top of each other to hope that the combination gives a new particle.

### There is a point system in relation to the combination found to unlock other elementary quarks.

#### Other game modes are in development.
Have fun!
